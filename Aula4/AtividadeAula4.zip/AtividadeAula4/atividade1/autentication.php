<?php

echo "<h1>Dados do Formulário</h1>";
echo "E-mail: ". $_POST['nome']; 
echo "<br>";
echo "Senha: ". $_POST['idade'];
echo "<br>";
echo "Lembrar-me: ". $_POST['cidadeNatal'];